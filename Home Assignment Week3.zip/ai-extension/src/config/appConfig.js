export const appConfig = {
  appName: 'QAI Coder',
  Path: 'assets/images/logo-small.png',
  colors: {
    primary: '#480355',
    primaryLight: '#6F1E88',
    accent: '#FFB700',
    success: '#00C853',
    successDark: '#00994D',
    danger: '#D50000',
    darkBg: '#2D0036',
    panelBg: '#1A001F',
    mutedText: '#B388FF',
    // Inspector toggle specific colors
    gradientStart: '#480355',
    shadowColor: 'rgba(72,3,85,0.3)',
    shadowColorHover: 'rgba(255,183,0,0.4)',
    shadowColorActive: 'rgba(72,3,85,0.1)',
    borderWhite: 'rgba(255,255,255,0.1)'
  }
};